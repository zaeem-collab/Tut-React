import React from 'react'

export default function Alert(props) {

  const capital = (word)=> {

   const lower = word.toLowerCase();
   return lower.charAt(0).toUpperCase() + lower.slice(1);

  }

  return (
    props.alert && <div className={`alert alert-${props.alert.type} alert-dismissible fade show`} role="alert">
        <strong>{capital(props.alert.type)}</strong> : {props.alert.msg}
    {/* <button type="button" className="btn-close" data-bs-dismiss="alert" aria-label="Close"></button> */}
    </div>
  )
}

// Initially tu hamara props.alert null hain so error a rha hum ak condition use krein gay es ko fix krnay k liye props.alert && es ka mtlb k agr null hai tu false kr do aur agay ki cheez phr evaluate hi ni hoti aur agr ye true hai ye jo neechy likha wo return kr do

// This happens because all the JSX will be converted to js calls

// return k neechy wali line mai jo alert-warning ko remove kr k {props.alert.type} ye jo likha hai wo ap k alert ko green kr da ga

// capital function mai hum phly lower case mai kr rhy phr hum charAt(0) means first character ko select kia aur us ko uppercase mai kra and then lower.slice(1) ka mtlb ak ko chor k baqi sb ko lowercase mai kr do

// type mai capital function ko es liye dala ku k success type mai ata hai r msg phr ap ka alert message