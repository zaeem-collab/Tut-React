import React, {useState} from 'react'

export default function Form(props) {

  const handleupclick = () => {

  // console.log("Got Clicked!");
  let newText = Text.toUpperCase();
  setText(newText);
  // setText("It got Clicked!");
  props.showalert("Converted to UpperCase!" , "success");

  }
  const handlelowclick = () => {

  // console.log("Got Clicked!");
  let newText = Text.toLowerCase();
  setText(newText);
  props.showalert("Converted to LowerCase!" , "success");


  }

  const handleclearclick = () => {

    let newText = " ";
    setText(newText);
    props.showalert("Text Cleared!" , "success");
  
  
    }

  const change = (event) => {

  console.log("On change");
  setText(event.target.value);

  }

  const [Text, setText] = useState('');
  return (
    <>
    <div>
      
  <div className="container" style={{color : props.mode === "dark" ? "white": "black"}}>
  <div className= "mb-3" >
  <h1>{props.heading} </h1>
  <textarea className="form-control" value = {Text} onChange={change} id="myBox" rows="8" style={{backgroundColor : props.mode === "dark" ? "grey": "white" , color : props.mode === "dark" ? "white": "black"}}></textarea>
  </div>
  <button className="btn btn-primary" onClick={handleupclick}>Convert to UpperCase</button>
  <button className="btn btn-success mx-3" onClick={handlelowclick}>Convert to LowerCase</button>
  <button className="btn btn-danger mx-3 col-2 ms-2" onClick={handleclearclick}>Clear Text</button>

    </div>
    </div>

    <div className="container my-3" style={{color : props.mode === "dark" ? "white": "black"}}>
      <h2>Your Text Summary</h2>
      <p>{Text.split(" ").length} words and {Text.length} characters</p>
      <p>{0.008 * Text.split(" ").length }minutes to read</p>
      <h2>Preview</h2>
      <p>{Text.length>0 ? Text : " Enter Something In the Text-box above to preview it Here...."}</p>

    </div>
    </>
  )
}

// {useState} is a hook which we can use without writing a class in function based component

// Text = "Update Text"  // Wrong way to update state
// setText("Update Text");  // Correct way to update state

// onchange event hamay ak event object b da ga

// onchange event hm na text area mai type krnay k liye use kra jo k must hai

// Text.split means text ko split kr do with a space and ye ak array return kry ga aur jo us ki length ho gi wo num of words count kry ga but with space and Text.length ap ko no of characters return kry ga

// 0.008 is time to read one word calculated from google

// space ko ak word count kr rha hai ye default error hai agr ap ki string ak space pa end ho rhi ap ya blank hai ap ak word kam kr skty ho

// form control headings aur container mai two curly braces use ki hain ku k ak curly braces tu hain k ap backticks lga kr js likho aur dosri curly braces mai ap us js k andr object likh rhy ho like props.mode jo text k color ko dark mai white kr rha aur light mode mode and black kr rha hai like this.