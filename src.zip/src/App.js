
import './App.css';
import Navbar from './Components/Navbar';
import Form from './Components/Form';
import { useState } from 'react';
// import About from './Components/About';
import Alert from './Components/Alert';

// import {
//   BrowserRouter as Router,
//   Route,
//   Link,
//   Routes
// } from "react-router-dom";

function App() {

const [mode , setmode] = useState('light'); // whether dark mode is enabled or not
const [alert , setalert] = useState(null); 

const showalert = (message , type)=> {

 setalert ({

 msg : message, 
 type : type

 })

 setTimeout(() => {
  
 setalert(null);

 }, 1800);

}

const togglemode = ()=>{

if(mode === 'light'){

setmode('dark');
document.body.style.backgroundColor = '#042743'
showalert("Dark mode has been enabled" , "success");
document.title = "UI Design - Dark mode";

}

else{

setmode('light');
document.body.style.backgroundColor = 'white'
showalert("light mode has been enabled" , "success");
document.title = "UI Design - light mode";

}

}

  return (

   <>

    {/* <Navbar title = "ZaeemApp" aboutText = "About CEO"/> */}
    {/* <Router> */}
    <Navbar title = "ZaeemApp" mode = {mode} togglemode = {togglemode} aboutText = "About CEO"/>
    <Alert alert = {alert}/>
    <div className="container my-3">
      {/* <Routes>
          <Route exact path="/about" element = 
           { <About/>} /> */}
          {/* <Route exact path="/" element = */}
           <Form showalert = {showalert} heading = "Enter your text here" mode = {mode}/>
       {/* </Routes> */}
    </div>
    {/* </Router> */}



  </>

  );
}

export default App;

// do not pass values here in navbar while using default props

// uper ap showalert function call kro gy na k setalert

// React router no longer supports switch so use routes instead of switch

// Always a good idea to use "exact path = " ku k es sa react exact matching krta aur agr use ni krty tu react partial matching krta hai

// Router jo hm na hataya ya htaya tha wo just github pages k liye comment kia ku k github pages router ko support ni krta